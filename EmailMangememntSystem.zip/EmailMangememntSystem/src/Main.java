import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Email{
    private String sender;
    private String subject;
    private String message;

    public Email(String sender,String subject,String message){
        this.sender = sender;
        this.subject = subject;
        this.subject = message;
    }

    public String getSender(){
        return sender;
    }

    public String getSubject(){
        return subject;
    }

    public String getMessage(){
        return message;
    }
}

class EmailManagementSystem {
    private List<Email> inbox;

    public EmailManagementSystem() {
        inbox = new ArrayList<>();

    }

    public void sendEmail(String sender, String subject, String message) {
        Email email = new Email(sender, subject, message);
        inbox.add(email);
        System.out.println("Email sent successfully!! ");
    }

    public void viewInbox() {
        if (inbox.isEmpty()) {
            System.out.println("Inbox is empty");
        } else {
            System.out.println("------Inbox-------");
            for (int i = 0; i < inbox.size(); i++) {
                Email email = inbox.get(i);
                System.out.println("From: " + email.getSender());
                System.out.println("Subject: " + email.getSubject());
                System.out.println("Message: " + email.getMessage());
                System.out.println("---------------------");
            }
        }
    }



    public void deleteEmail(int index) {
        if (index >= 0 && index < inbox.size()) {
            inbox.remove(index);
            System.out.println("Email deleted successfully!");
        } else {
            System.out.println("Invalid email index.");
        }
    }
}


public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EmailManagementSystem emailSystem = new EmailManagementSystem();

        while (true){
            System.out.println("----- Welcome QuiteZ Mails -----");
            System.out.println("1. Send Email");
            System.out.println("2. View Inbox");
            System.out.println("3. Delete Email");
            System.out.println("4. Quit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter sender: ");
                    String sender = scanner.nextLine();
                    System.out.print("Enter subject: ");
                    String subject = scanner.nextLine();
                    System.out.print("Enter message: ");
                    String message = scanner.nextLine();
                    emailSystem.sendEmail(sender, subject, message);
                    break;
                case 2:
                    emailSystem.viewInbox();
                    break;
                case 3:
                    System.out.print("Enter the index of the email to delete: ");
                    int index = scanner.nextInt();
                    emailSystem.deleteEmail(index);
                    break;
                case 4:
                    System.out.println("Exiting the program. Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }

            System.out.println();

        }
    }
}